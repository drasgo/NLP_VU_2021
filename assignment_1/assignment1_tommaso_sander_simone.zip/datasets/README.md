## SemEval-2018 Task 3 datasets ##

In this repository you will find the datasets for SemEval-2018 Task 3:

* Example datasets (Task A and Task B) + trial dataset Task A
* Training datasets (Task A and Task B)
* Test datasets (Task A and Task B) - to be released in January 2018

## Useful links: ##
* <a href="https://competitions.codalab.org/competitions/17468" target="_blank">CodaLab website of the task</a>
* <a href="http://alt.qcri.org/semeval2018/index.php?id=tasks" target="_blank">SemEval-2018 website</a>
* <a href="https://groups.google.com/forum/#!forum/semeval2018-task3" target="_blank">SemEval-2018 Task 3 Google group</a>


## Task organisers: ##
* Cynthia Van Hee
* Els Lefever
* Véronique Hoste

LT3, Language and Translation Technology Team, Ghent University, Belgium


